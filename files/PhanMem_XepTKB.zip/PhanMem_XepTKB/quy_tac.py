#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
==========================================================================
 DANH MỤC QUY TẮC XẾP THỜI KHÓA BIỂU
--------------------------------------------------------------------------
 Mỗi quy tắc là 1 lớp Python được "đăng ký" vào DANH_MUC bằng @dang_ky.
 Muốn thêm loại quy tắc mới -> copy 1 lớp có sẵn, đổi tên, sửa 1-2 hàm.
 Không phải đụng vào xep_tkb.py.

 Mỗi quy tắc có tối đa 5 "móc nối" (hook), cài cái nào cần thì cài:

   thu_hep_mien()            chạy 1 LẦN trước khi giải — cắt bớt ngày/tiết
                             mà cụm được phép vào. Nhanh nhất, ưu tiên dùng.
   cho_phep(gs, c, ngay, v)  chạy TRONG lúc giải — trả False để chặn nước đi.
   dat(gs, c) / go(gs, c)    cập nhật bộ đếm riêng khi đặt/gỡ 1 cụm.
   hau_kiem()                chạy SAU khi giải — trả list mô tả chỗ vi phạm.
   diem()                    điểm mềm — càng cao càng được ưu tiên chọn.
   thich(gs, c, ngay, v)     True = "ô này đẹp" -> chương trình thử ô đó trước.
   hoan(gs, c)               True = "khoan hãy xếp cụm này, chờ cụm khác đã".

 Cụm (Cum) = nhóm tiết liên tiếp của cùng 1 môn / 1 GV / 1 lớp.
   c.lop c.mon c.nhom c.gv c.size c.la_cd c.ngay c.vitri
   ngay  = chỉ số ngày 0,1,2...  (0 = thứ đầu tiên trong "cac_thu")
   vitri = chỉ số tiết trong buổi 0,1,2... (0 = tiết đầu buổi)
==========================================================================
"""

from collections import defaultdict

DANH_MUC = {}


def dang_ky(ten):
    def deco(cls):
        cls.TEN = ten
        DANH_MUC[ten] = cls
        return cls
    return deco


# ==========================================================================
# LỚP NỀN
# ==========================================================================

class QuyTac:
    TEN = ''
    MO_TA = ''
    VI_DU = {}
    CAN_TRONG_KHI_GIAI = False       # True nếu có dùng cho_phep()/dat()/go()
    CO_GOI_Y = False                 # True nếu có dùng thich()/hoan()

    def __init__(self, r, bt):
        self.r = r
        self.bt = bt
        self.ghi_chu = r.get('ghi_chu') or r.get('_ghichu') or self.MO_TA

    # ---------------- tiện ích dùng chung ----------------
    def loc(self, khoa='loc'):
        return self.r.get(khoa, {})

    def khop(self, c, dk=None):
        """Cụm c có thoả bộ lọc dk không? dk gồm: mon / nhom_mon / gv / lop /
           la_chuyen_de. Giá trị viết 1 chuỗi hoặc 1 danh sách đều được."""
        if c.la_trong:
            return False
        if dk is None:
            dk = self.loc()

        def co(khoa, gt):
            if khoa not in dk:
                return True
            ds = dk[khoa]
            if not isinstance(ds, list):
                ds = [ds]
            return gt in ds

        if not co('mon', c.mon):
            return False
        if not co('nhom_mon', c.nhom):
            return False
        if not co('gv', c.gv):
            return False
        if not co('lop', c.lop):
            return False
        if 'la_chuyen_de' in dk and bool(dk['la_chuyen_de']) != c.la_cd:
            return False
        return True

    def cac_cum(self, dk=None):
        return [c for c in self.bt.cac_cum if self.khop(c, dk)]

    def tap_ngay(self, khoa='thu'):
        return {self.bt.thu2idx[t] for t in self.r.get(khoa, [])
                if t in self.bt.thu2idx}

    def tap_tiet(self):
        """Gộp 'tiet' (số hiệu tiết thật) và 'tiet_trong_buoi' (thứ tự trong buổi)."""
        v = set()
        for t in self.r.get('tiet_trong_buoi', []):
            if 1 <= t <= self.bt.SO_TIET:
                v.add(t - 1)
        for t in self.r.get('tiet', []):
            if t in self.bt.tiet2idx:
                v.add(self.bt.tiet2idx[t])
        return v

    def ten_o(self, c):
        return (f'{c.lop}/{c.mon} Thứ {self.bt.cac_thu[c.ngay]} '
                f'tiết {self.bt.cac_tiet[c.vitri]}')

    # ---------------- các móc nối ----------------
    def thu_hep_mien(self):
        pass

    def lien_quan(self, c):
        return self.khop(c)

    def cho_phep(self, gs, c, ngay, vitri):
        return True

    def dat(self, gs, c):
        pass

    def go(self, gs, c):
        pass

    def hau_kiem(self):
        return []

    def diem(self):
        return 0

    def thich(self, gs, c, ngay, vitri):
        return False

    def hoan(self, gs, c):
        return False

    # --- tiện ích cho các quy tắc kiểu "hai nhóm a / b" ---
    def _ben(self, c):
        v = []
        if self.khop(c, self.r.get('a', {})):
            v.append('a')
        if self.khop(c, self.r.get('b', {})):
            v.append('b')
        return v

    def _ke(self, c, ngay, vitri, k):
        return k.ngay == ngay and (k.vitri + k.size == vitri
                                   or vitri + c.size == k.vitri)


# ==========================================================================
# NHÓM 1 — GIỚI HẠN NGÀY / TIẾT   (cắt miền, chạy 1 lần, rất nhanh)
# ==========================================================================

@dang_ky('chi_xep_thu')
class ChiXepThu(QuyTac):
    MO_TA = 'Chỉ được xếp vào những thứ liệt kê.'
    VI_DU = {"loai": "chi_xep_thu",
             "ghi_chu": "Vật lý 12B1, 12B2 chỉ Thứ 2 hoặc Thứ 3",
             "loc": {"mon": "Vật lý", "lop": ["12B1", "12B2"]},
             "thu": [2, 3]}

    def thu_hep_mien(self):
        ok = self.tap_ngay()
        for c in self.cac_cum():
            c.ngay_ok &= ok

    def hau_kiem(self):
        ok = self.tap_ngay()
        return [self.ten_o(c) for c in self.cac_cum() if c.ngay not in ok]


@dang_ky('khong_xep_thu')
class KhongXepThu(QuyTac):
    MO_TA = 'Cấm xếp vào những thứ liệt kê.'
    VI_DU = {"loai": "khong_xep_thu",
             "ghi_chu": "Văn cô Duy không xếp Thứ 2",
             "loc": {"gv": "Đ.Duy"},
             "thu": [2]}

    def thu_hep_mien(self):
        cam = self.tap_ngay()
        for c in self.cac_cum():
            c.ngay_ok -= cam

    def hau_kiem(self):
        cam = self.tap_ngay()
        return [self.ten_o(c) for c in self.cac_cum() if c.ngay in cam]


@dang_ky('chi_xep_tiet')
class ChiXepTiet(QuyTac):
    MO_TA = 'Chỉ được xếp vào những tiết liệt kê (cả cụm phải nằm gọn trong đó).'
    VI_DU = {"loai": "chi_xep_tiet",
             "ghi_chu": "GDKT-PL luôn ở 2 tiết cuối buổi",
             "loc": {"mon": "GDKT-PL"},
             "tiet_trong_buoi": [4, 5]}

    def thu_hep_mien(self):
        ok = self.tap_tiet()
        for c in self.cac_cum():
            c.vitri_ok = {v for v in c.vitri_ok
                          if set(range(v, v + c.size)) <= ok}

    def hau_kiem(self):
        ok = self.tap_tiet()
        return [self.ten_o(c) for c in self.cac_cum()
                if not set(range(c.vitri, c.vitri + c.size)) <= ok]


@dang_ky('khong_xep_tiet')
class KhongXepTiet(QuyTac):
    MO_TA = ('Cấm những tiết liệt kê. "tiet_trong_buoi": 1 = tiết đầu buổi. '
             '"tiet": ghi số hiệu tiết thật (6, 7, 8...).')
    VI_DU = {"loai": "khong_xep_tiet",
             "ghi_chu": "Sử cô Ngọc Uyên không xếp tiết 4 và tiết 5 của buổi",
             "loc": {"gv": "N.Uyên", "nhom_mon": "Sử"},
             "tiet_trong_buoi": [4, 5]}

    def thu_hep_mien(self):
        cam = self.tap_tiet()
        for c in self.cac_cum():
            c.vitri_ok = {v for v in c.vitri_ok
                          if not (set(range(v, v + c.size)) & cam)}

    def hau_kiem(self):
        cam = self.tap_tiet()
        return [self.ten_o(c) for c in self.cac_cum()
                if set(range(c.vitri, c.vitri + c.size)) & cam]


@dang_ky('khong_xep_o')
class KhongXepO(QuyTac):
    MO_TA = ('Cấm từng ô cụ thể (thứ + tiết). Dùng khi giáo viên bận cố định '
             'một vài buổi. Ghi "o": [[thứ, tiết], [thứ, tiết], ...]')
    VI_DU = {"loai": "khong_xep_o",
             "ghi_chu": "Thầy Nam bận họp Thứ 4 tiết 6, 7",
             "loc": {"gv": "H.Nam"},
             "o": [[4, 6], [4, 7]]}

    def _tap_o(self):
        v = set()
        for thu, tiet in self.r.get('o', []):
            if thu in self.bt.thu2idx and tiet in self.bt.tiet2idx:
                v.add((self.bt.thu2idx[thu], self.bt.tiet2idx[tiet]))
        return v

    def thu_hep_mien(self):
        cam = self._tap_o()
        for c in self.cac_cum():
            c.o_cam |= cam

    def hau_kiem(self):
        cam = self._tap_o()
        return [self.ten_o(c) for c in self.cac_cum()
                if any((c.ngay, p) in cam
                       for p in range(c.vitri, c.vitri + c.size))]


@dang_ky('co_dinh')
class CoDinh(QuyTac):
    MO_TA = ('Ghim cứng vào đúng 1 ô (thứ + tiết). Nếu bộ lọc khớp nhiều cụm '
             'thì chỉ cụm đầu tiên của mỗi lớp bị ghim.')
    VI_DU = {"loai": "co_dinh",
             "ghi_chu": "SHCN 12B1 cố định Thứ 6 tiết 10",
             "loc": {"mon": "SHCN", "lop": "12B1"},
             "thu": 6, "tiet": 10}

    def thu_hep_mien(self):
        bt = self.bt
        d = bt.thu2idx.get(self.r.get('thu'))
        if 'tiet' in self.r:
            v = bt.tiet2idx.get(self.r['tiet'])
        else:
            v = self.r.get('tiet_trong_buoi', 1) - 1
        if d is None or v is None:
            return
        da_ghim = set()
        for c in self.cac_cum():
            if c.lop in da_ghim:
                continue
            da_ghim.add(c.lop)
            c.ngay_ok = {d} & c.ngay_ok
            c.vitri_ok = {v} & c.vitri_ok


# ==========================================================================
# NHÓM 2 — QUAN HỆ GIỮA CÁC TIẾT   (kiểm tra trong lúc giải)
# ==========================================================================

@dang_ky('khac_ngay')
class KhacNgay(QuyTac):
    MO_TA = ('Hai nhóm tiết không được rơi vào cùng một ngày. '
             '"pham_vi": "toan_truong" (mặc định) hoặc "moi_lop" (chỉ xét '
             'trong phạm vi từng lớp).')
    VI_DU = {"loai": "khac_ngay",
             "ghi_chu": "Sử cô Lê Xuân không cùng ngày với lịch thầy Hùng",
             "a": {"gv": "N.Xuân"},
             "b": {"gv": "M.Hùng"},
             "pham_vi": "toan_truong"}
    CAN_TRONG_KHI_GIAI = True

    def __init__(self, r, bt):
        super().__init__(r, bt)
        self.theo_lop = r.get('pham_vi') == 'moi_lop'
        self.dem = defaultdict(int)

    def lien_quan(self, c):
        return bool(self._ben(c))

    def _khoa(self, ben, c, ngay):
        return (ben, c.lop if self.theo_lop else '*', ngay)

    def cho_phep(self, gs, c, ngay, vitri):
        for ben in self._ben(c):
            doi = 'b' if ben == 'a' else 'a'
            if self.dem[self._khoa(doi, c, ngay)] > 0:
                return False
        return True

    def dat(self, gs, c):
        for ben in self._ben(c):
            self.dem[self._khoa(ben, c, c.ngay)] += 1

    def go(self, gs, c):
        for ben in self._ben(c):
            self.dem[self._khoa(ben, c, c.ngay)] -= 1

    def hau_kiem(self):
        na, nb = defaultdict(set), defaultdict(set)
        for c in self.bt.cac_cum:
            k = c.lop if self.theo_lop else '*'
            if self.khop(c, self.r['a']):
                na[k].add(c.ngay)
            if self.khop(c, self.r['b']):
                nb[k].add(c.ngay)
        loi = []
        for k in na:
            for d in na[k] & nb[k]:
                loi.append(f'{k} Thứ {self.bt.cac_thu[d]}')
        return loi


@dang_ky('cung_ngay')
class CungNgay(QuyTac):
    MO_TA = ('Mọi tiết của nhóm a phải rơi vào ngày mà nhóm b cũng có tiết '
             '(vd: chuyên đề học đúng ngày có tiết chính).')
    VI_DU = {"loai": "cung_ngay",
             "ghi_chu": "Chuyên đề Toán học đúng ngày có tiết Toán chính",
             "a": {"mon": "Chuyên đề Toán"},
             "b": {"mon": "Toán học"}}
    CAN_TRONG_KHI_GIAI = True
    CO_GOI_Y = True

    def __init__(self, r, bt):
        super().__init__(r, bt)
        self.cum_b = [c for c in bt.cac_cum if self.khop(c, r['b'])]

    def lien_quan(self, c):
        return bool(self._ben(c))

    def _b_cung_lop(self, c):
        return [k for k in self.cum_b if k.lop == c.lop]

    def cho_phep(self, gs, c, ngay, vitri):
        if 'a' not in self._ben(c):
            return True
        bs = self._b_cung_lop(c)
        if not bs or any(k.ngay is None for k in bs):
            return True                      # chưa đủ dữ kiện, chưa kết luận
        return ngay in {k.ngay for k in bs}

    def hoan(self, gs, c):
        return ('a' in self._ben(c)
                and any(k.ngay is None for k in self._b_cung_lop(c)))

    def thich(self, gs, c, ngay, vitri):
        if 'a' not in self._ben(c):
            return False
        return ngay in {k.ngay for k in self._b_cung_lop(c) if k.ngay is not None}

    def hau_kiem(self):
        loi = []
        for c in self.bt.cac_cum:
            if 'a' not in self._ben(c):
                continue
            ng = {k.ngay for k in self._b_cung_lop(c)}
            if ng and c.ngay not in ng:
                loi.append(self.ten_o(c))
        return loi


@dang_ky('toi_da_tiet_moi_ngay')
class ToiDaTietMoiNgay(QuyTac):
    MO_TA = ('Giới hạn số tiết trong 1 ngày. "theo": "gv" | "lop" | "mon_lop" '
             '(số tiết của cùng 1 môn trong 1 lớp).')
    VI_DU = {"loai": "toi_da_tiet_moi_ngay",
             "ghi_chu": "Mỗi giáo viên dạy tối đa 4 tiết/buổi",
             "loc": {}, "theo": "gv", "so": 4}
    CAN_TRONG_KHI_GIAI = True

    def __init__(self, r, bt):
        super().__init__(r, bt)
        self.theo = r.get('theo', 'gv')
        self.so = r.get('so', 5)
        self.dem = defaultdict(int)

    def _khoa(self, c):
        if self.theo == 'gv':
            return c.gv
        if self.theo == 'lop':
            return c.lop
        return (c.lop, c.mon)

    def cho_phep(self, gs, c, ngay, vitri):
        return self.dem[(self._khoa(c), ngay)] + c.size <= self.so

    def dat(self, gs, c):
        self.dem[(self._khoa(c), c.ngay)] += c.size

    def go(self, gs, c):
        self.dem[(self._khoa(c), c.ngay)] -= c.size

    def hau_kiem(self):
        d = defaultdict(int)
        for c in self.cac_cum():
            d[(self._khoa(c), c.ngay)] += c.size
        return [f'{k} Thứ {self.bt.cac_thu[n]}: {v} tiết'
                for (k, n), v in d.items() if v > self.so]


@dang_ky('toi_da_ngay_moi_tuan')
class ToiDaNgayMoiTuan(QuyTac):
    MO_TA = ('Giới hạn số buổi phải lên lớp trong tuần. '
             '"theo": "gv" (mặc định) | "lop".')
    VI_DU = {"loai": "toi_da_ngay_moi_tuan",
             "ghi_chu": "Cô Ngọc Uyên chỉ lên lớp tối đa 3 buổi/tuần",
             "loc": {"gv": "N.Uyên"}, "theo": "gv", "so": 3}
    CAN_TRONG_KHI_GIAI = True

    def __init__(self, r, bt):
        super().__init__(r, bt)
        self.theo = r.get('theo', 'gv')
        self.so = r.get('so', 5)
        self.dem = defaultdict(int)

    def _khoa(self, c):
        return c.gv if self.theo == 'gv' else c.lop

    def cho_phep(self, gs, c, ngay, vitri):
        k = self._khoa(c)
        if self.dem[(k, ngay)] > 0:
            return True
        return sum(1 for (kk, _), n in self.dem.items()
                   if kk == k and n > 0) < self.so

    def dat(self, gs, c):
        self.dem[(self._khoa(c), c.ngay)] += 1

    def go(self, gs, c):
        self.dem[(self._khoa(c), c.ngay)] -= 1

    def hau_kiem(self):
        d = defaultdict(set)
        for c in self.cac_cum():
            d[self._khoa(c)].add(c.ngay)
        return [f'{k}: {len(v)} buổi' for k, v in d.items() if len(v) > self.so]


@dang_ky('khong_ke_nhau')
class KhongKeNhau(QuyTac):
    MO_TA = 'Hai nhóm môn của cùng một lớp không được xếp sát nhau (liền tiết).'
    VI_DU = {"loai": "khong_ke_nhau",
             "ghi_chu": "Không xếp Toán ngay sát Vật lý",
             "a": {"nhom_mon": "Toán"},
             "b": {"nhom_mon": "Lý"}}
    CAN_TRONG_KHI_GIAI = True

    def lien_quan(self, c):
        return bool(self._ben(c))

    def cho_phep(self, gs, c, ngay, vitri):
        ben = self._ben(c)
        if not ben:
            return True
        hang = gs.lich[c.lop][ngay]
        for p in (vitri - 1, vitri + c.size):
            if 0 <= p < self.bt.SO_TIET:
                k = hang[p]
                if k is None or k.la_trong:
                    continue
                kb = self._ben(k)
                if ('a' in ben and 'b' in kb) or ('b' in ben and 'a' in kb):
                    return False
        return True

    def hau_kiem(self):
        loi = []
        for c in self.bt.cac_cum:
            if 'a' not in self._ben(c):
                continue
            for k in self.bt.cac_cum:
                if k.lop != c.lop or k.ngay != c.ngay or 'b' not in self._ben(k):
                    continue
                if k.vitri + k.size == c.vitri or c.vitri + c.size == k.vitri:
                    loi.append(self.ten_o(c))
        return loi


@dang_ky('phai_ke_nhau')
class PhaiKeNhau(QuyTac):
    MO_TA = ('Mọi tiết của nhóm a phải nằm sát nhóm b, cùng lớp cùng buổi '
             '(vd: chuyên đề luôn nối tiếp tiết chính). Đây là quy tắc CỨNG — '
             'nếu quá khó xếp hãy đổi sang "uu_tien_ke_nhau".')
    VI_DU = {"loai": "phai_ke_nhau",
             "ghi_chu": "Chuyên đề Toán phải nối tiếp tiết Toán chính",
             "a": {"mon": "Chuyên đề Toán"},
             "b": {"mon": "Toán học"}}
    CAN_TRONG_KHI_GIAI = True
    CO_GOI_Y = True

    def __init__(self, r, bt):
        super().__init__(r, bt)
        self.cum_b = [c for c in bt.cac_cum if self.khop(c, r['b'])]

    def lien_quan(self, c):
        return bool(self._ben(c))

    def _b_cung_lop(self, c):
        return [k for k in self.cum_b if k.lop == c.lop]

    def cho_phep(self, gs, c, ngay, vitri):
        if 'a' not in self._ben(c):
            return True
        bs = self._b_cung_lop(c)
        if not bs or any(k.ngay is None for k in bs):
            return True                      # chờ nhóm b xếp xong đã
        return any(self._ke(c, ngay, vitri, k) for k in bs)

    def hoan(self, gs, c):
        return ('a' in self._ben(c)
                and any(k.ngay is None for k in self._b_cung_lop(c)))

    def thich(self, gs, c, ngay, vitri):
        if 'a' not in self._ben(c):
            return False
        return any(self._ke(c, ngay, vitri, k)
                   for k in self._b_cung_lop(c) if k.ngay is not None)

    def hau_kiem(self):
        loi = []
        for c in self.bt.cac_cum:
            if 'a' not in self._ben(c):
                continue
            bs = [k for k in self._b_cung_lop(c)]
            if not any(self._ke(c, c.ngay, c.vitri, k) for k in bs):
                loi.append(self.ten_o(c))
        return loi


# ==========================================================================
# NHÓM 3 — GOM TIẾT (xử lý ngay lúc tạo cụm, xem xep_tkb.py)
# ==========================================================================

@dang_ky('gom_tiet')
class GomTiet(QuyTac):
    MO_TA = ('Đổi cách chia cụm cho riêng một môn/lớp, đè lên "dinh_muc_mon". '
             '[2] = 2 tiết dính liền; [1,1] = tách 2 buổi; [2,1] = 1 buổi 2 '
             'tiết + 1 buổi 1 tiết.')
    VI_DU = {"loai": "gom_tiet",
             "ghi_chu": "Riêng 12B5, 12B6 tách Hoá ra 2 buổi",
             "loc": {"mon": "Hoá học", "lop": ["12B5", "12B6"]},
             "cum": [1, 1]}


# ==========================================================================
# NHÓM 4 — TIÊU CHÍ MỀM (không bắt buộc, chỉ cộng/trừ điểm)
# ==========================================================================

@dang_ky('uu_tien_o')
class UuTienO(QuyTac):
    MO_TA = ('Cộng điểm nếu xếp đúng thứ/tiết mong muốn (điểm âm = tránh). '
             'Không bắt buộc, chỉ dùng để chọn phương án đẹp hơn.')
    VI_DU = {"loai": "uu_tien_o",
             "ghi_chu": "Ưu tiên Toán, Văn vào 2 tiết đầu buổi",
             "loc": {"nhom_mon": ["Toán", "Văn"]},
             "tiet_trong_buoi": [1, 2],
             "diem": 3}

    def diem(self):
        ng = self.tap_ngay() if 'thu' in self.r else None
        ti = self.tap_tiet() if ('tiet' in self.r or
                                 'tiet_trong_buoi' in self.r) else None
        d, dv = 0, self.r.get('diem', 1)
        for c in self.cac_cum():
            if ng is not None and c.ngay not in ng:
                continue
            if ti is not None and not (set(range(c.vitri, c.vitri + c.size)) & ti):
                continue
            d += dv * c.size
        return d


@dang_ky('uu_tien_ke_nhau')
class UuTienKeNhau(QuyTac):
    MO_TA = 'Cộng điểm khi nhóm a nằm sát nhóm b trong cùng lớp, cùng buổi.'
    VI_DU = {"loai": "uu_tien_ke_nhau",
             "ghi_chu": "Nên xếp chuyên đề nối tiếp tiết chính",
             "a": {"la_chuyen_de": True},
             "b": {"la_chuyen_de": False},
             "cung_nhom_mon": True,
             "diem": 12}
    CO_GOI_Y = True

    def _hop(self, c, k):
        if not self.khop(k, self.r['b']):
            return False
        return not (self.r.get('cung_nhom_mon', False) and k.nhom != c.nhom)

    def thich(self, gs, c, ngay, vitri):
        if not self.khop(c, self.r['a']):
            return False
        hang = gs.lich[c.lop][ngay]
        for p in (vitri - 1, vitri + c.size):
            if 0 <= p < self.bt.SO_TIET:
                k = hang[p]
                if k is not None and not k.la_trong and self._hop(c, k):
                    return True
        return False

    def hoan(self, gs, c):
        if not self.khop(c, self.r['a']):
            return False
        return any(k.ngay is None for k in gs.bt.cac_cum
                   if k.lop == c.lop and k is not c and self._hop(c, k))

    def diem(self):
        dv = self.r.get('diem', 1)
        cung = self.r.get('cung_nhom_mon', False)
        d = 0
        for c in self.bt.cac_cum:
            if not self.khop(c, self.r['a']):
                continue
            for k in self.bt.cac_cum:
                if k is c or k.lop != c.lop or k.ngay != c.ngay:
                    continue
                if not self.khop(k, self.r['b']):
                    continue
                if cung and k.nhom != c.nhom:
                    continue
                if k.vitri + k.size == c.vitri or c.vitri + c.size == k.vitri:
                    d += dv
                    break
        return d


@dang_ky('uu_tien_it_buoi')
class UuTienItBuoi(QuyTac):
    MO_TA = ('Trừ điểm theo tổng số buổi giáo viên phải lên lớp — càng dồn '
             'buổi cho thầy cô càng được điểm cao.')
    VI_DU = {"loai": "uu_tien_it_buoi", "loc": {}, "diem": 4}

    def diem(self):
        ng = defaultdict(set)
        for c in self.cac_cum():
            ng[c.gv].add(c.ngay)
        return -self.r.get('diem', 1) * sum(len(v) for v in ng.values())


@dang_ky('uu_tien_trai_deu')
class UuTienTraiDeu(QuyTac):
    MO_TA = ('Cộng điểm khi hai buổi học của cùng một môn (trong cùng lớp) '
             'cách nhau từ "cach" ngày trở lên.')
    VI_DU = {"loai": "uu_tien_trai_deu", "loc": {}, "cach": 2, "diem": 3}

    def diem(self):
        cach = self.r.get('cach', 2)
        dv = self.r.get('diem', 1)
        nh = defaultdict(list)
        for c in self.cac_cum():
            if not c.la_cd:
                nh[(c.lop, c.mon)].append(c.ngay)
        d = 0
        for ds in nh.values():
            ds.sort()
            for i in range(len(ds) - 1):
                if ds[i + 1] - ds[i] >= cach:
                    d += dv
        return d


# ==========================================================================
# IN DANH MỤC RA MÀN HÌNH
# ==========================================================================

def in_danh_muc():
    import json
    nhom = [
        ('GIỚI HẠN NGÀY / TIẾT',
         ['chi_xep_thu', 'khong_xep_thu', 'chi_xep_tiet', 'khong_xep_tiet',
          'khong_xep_o', 'co_dinh']),
        ('QUAN HỆ GIỮA CÁC TIẾT',
         ['khac_ngay', 'cung_ngay', 'toi_da_tiet_moi_ngay',
          'toi_da_ngay_moi_tuan', 'khong_ke_nhau', 'phai_ke_nhau']),
        ('GOM TIẾT', ['gom_tiet']),
        ('TIÊU CHÍ MỀM (chỉ cộng/trừ điểm)',
         ['uu_tien_o', 'uu_tien_ke_nhau', 'uu_tien_it_buoi',
          'uu_tien_trai_deu']),
    ]
    print('=' * 74)
    print(' DANH MỤC QUY TẮC — chép mẫu bên dưới vào mục "quy_tac" của cauhinh.json')
    print('=' * 74)
    for ten_nhom, ds in nhom:
        print(f'\n### {ten_nhom}')
        for t in ds:
            cls = DANH_MUC[t]
            print(f'\n  ▸ {t}')
            for dong in _xuong_dong(cls.MO_TA, 68):
                print(f'      {dong}')
            print('      ' + _gon(cls.VI_DU).replace('\n', '\n      '))
    print('\n' + '=' * 74)
    print(' Bộ lọc "loc" dùng chung: mon / nhom_mon / gv / lop / la_chuyen_de.')
    print(' Mỗi khoá nhận 1 giá trị hoặc 1 danh sách. Bỏ trống = áp cho tất cả.')
    print(' Thêm "bat": false để tạm tắt một quy tắc mà không cần xoá.')
    print('=' * 74)


def _gon(obj):
    """In JSON dễ đọc: mỗi khoá 1 dòng, riêng danh sách thì gom lại 1 dòng."""
    import json
    import re
    s = json.dumps(obj, ensure_ascii=False, indent=2)
    s = re.sub(r'\[\s+([^\[\]{}]*?)\s+\]',
               lambda m: '[' + ', '.join(x.strip() for x in
                                         m.group(1).split(',')) + ']',
               s, flags=re.S)
    return s


def _xuong_dong(s, rong):
    tu, dong, ds = s.split(), '', []
    for t in tu:
        if len(dong) + len(t) + 1 > rong:
            ds.append(dong)
            dong = t
        else:
            dong = (dong + ' ' + t).strip()
    if dong:
        ds.append(dong)
    return ds


if __name__ == '__main__':
    in_danh_muc()
